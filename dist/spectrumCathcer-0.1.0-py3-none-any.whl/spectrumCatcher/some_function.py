class adsf():
	def __init__(self):
		print("cllaed")